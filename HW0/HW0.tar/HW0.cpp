#include <iostream>
using namespace std;
int main() {
   // Knock Knock
   cout << "Knock Knock\n"
   << "Who's There\n"
   << "Leaf\n" << "Leaf who?\n" 
   << "Leaf me alone!\n";
   return 0;
}